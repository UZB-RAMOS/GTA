# Toshkent Sarguzashti

`Toshkent Sarguzashti` — Toshkent mahallalari va keng ko‘chalaridan ilhomlangan original 3D ochiq-dunyo MVP o‘yini. Loyiha GTA kodi, xaritasi, modeli, musiqasi, logotipi yoki boshqa aktivlarini ishlatmaydi.

## Ishga tushirish

1. `builds/Toshkent_Sarguzashti.exe` faylini oching.
2. Asosiy menyudan **Yangi o‘yin** tugmasini bosing.
3. Sariq topshiriq belgilarini kuzating.

Talab: 64-bit Windows 10 yoki Windows 11 va OpenGL 3.3 bilan mos videokarta. O‘yin portable: alohida o‘rnatish talab qilmaydi.

Build mustaqil code-signing sertifikati bilan imzolanmagan. Shu sabab Windows SmartScreen ogohlantirish ko‘rsatishi mumkin; fayl yaxlitligini `CHECKSUMS.txt` dagi SHA-256 bilan tekshirish mumkin.

## Boshqaruv

| Tugma | Amal |
|---|---|
| `WASD` yoki strelkalar | Yurish yoki transportni boshqarish |
| `Shift` | Yugurish |
| `Space` | Sakrash; transportda qo‘l tormozi |
| Sichqon | Uchinchi shaxs kamerasi |
| `E` | Transportga kirish yoki undan chiqish |
| `F5` | O‘yinni saqlash |
| `F9` | Saqlangan o‘yinni yuklash |
| `Esc` | Pause menyusi |

## Tayyor imkoniyatlar

- procedural yaratilgan original shahar: yo‘llar, binolar, mahalla bozori, markaz, daraxtlar va ko‘rsatkichlar;
- piyoda yurish, yugurish, sakrash va uchinchi shaxs kamerasi;
- boshqariladigan ko‘k mikroavtobus;
- yo‘nalish bo‘ylab yuradigan 6 ta trafik avtomobili;
- aylanib yuradigan 16 ta piyoda NPC;
- JSON orqali yuklanadigan 4 bosqichli topshiriq va mukofot;
- HUD, minimap, asosiy menyu, pause va ovoz sozlamasi;
- versiyalangan save/load tizimi;
- Windows uchun bitta faylli `.exe` build.

## Loyiha tuzilishi

- `scripts/` — GDScript o‘yin kodlari;
- `data/mission_01.json` — data-driven topshiriq;
- `screenshots/` — tekshirilgan preview rasmlari;
- `builds/` — ishga tayyor Windows build va ZIP paket;
- `../REVERSE_ENGINEERING.md` — tadqiqot, dalillar va arxitektura hisoboti.

## Chegara

Bu tijoriy AAA o‘yin emas, balki yakunlangan va o‘ynaladigan vertical-slice MVP. Mobil versiya foydalanuvchi qaroriga ko‘ra loyiha doirasidan chiqarilgan. Multiplayer, qurol, jinoyat/qidiruv tizimi va to‘liq Toshkent xaritasi bu versiyaga kirmaydi.

Brend, pullik shrift va mualliflik huquqi bilan himoyalangan kontentni ruxsatsiz qo‘shmang. Keyingi barcha 3D model, musiqa va teksturalarning litsenziya dalilini saqlash tavsiya etiladi.
